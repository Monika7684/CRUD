from django.contrib import admin

# Register your models here.
from api.models import Employee


@admin.register(Employee)
class EmployeeADMIN(admin.ModelAdmin):
    list_display = ['id','name','empid','city']

