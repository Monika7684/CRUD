from rest_framework import serializers

from api.models import Employee


class EmployeeSerializer(serializers.Serializer):
    name = serializers.CharField(max_length=100)
    empid = serializers.IntegerField()
    city = serializers.CharField(max_length=100)
    def create(self, validated_data):
        return Employee.objects.create(**validated_data)

    def update(self, instance, validated_data):
        print(instance.name)
        instance.name=validated_data.get('name',instance.name)
        print((instance.name))
        instance.empid=validated_data.get('empid',instance.empid)
        instance.city=validated_data.get('city',instance.city)
        instance.save()
        return instance

